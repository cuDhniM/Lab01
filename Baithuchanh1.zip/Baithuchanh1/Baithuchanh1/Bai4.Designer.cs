﻿namespace Baithuchanh1
{
    partial class Bai4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Nhap = new TextBox();
            button1 = new Button();
            mua = new Button();
            comboBox1 = new ComboBox();
            Phim = new Label();
            label2 = new Label();
            comboBox2 = new ComboBox();
            Phòng = new Label();
            checkedListBox1 = new CheckedListBox();
            label3 = new Label();
            Xoa = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.GradientActiveCaption;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 24);
            label1.Name = "label1";
            label1.Size = new Size(291, 24);
            label1.TabIndex = 0;
            label1.Text = "Vui lòng nhập tên khách hàng";
            // 
            // Nhap
            // 
            Nhap.BackColor = SystemColors.ControlLight;
            Nhap.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Nhap.ForeColor = SystemColors.InactiveCaptionText;
            Nhap.Location = new Point(309, 17);
            Nhap.Name = "Nhap";
            Nhap.Size = new Size(421, 34);
            Nhap.TabIndex = 1;
            Nhap.TextChanged += Nhap_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.Brown;
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonFace;
            button1.Location = new Point(618, 405);
            button1.Name = "button1";
            button1.Size = new Size(112, 71);
            button1.TabIndex = 2;
            button1.Text = "Back to Menu";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // mua
            // 
            mua.BackColor = Color.LightSalmon;
            mua.BackgroundImageLayout = ImageLayout.Center;
            mua.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            mua.ForeColor = SystemColors.ButtonFace;
            mua.Location = new Point(137, 338);
            mua.Name = "mua";
            mua.Size = new Size(192, 83);
            mua.TabIndex = 3;
            mua.Text = "Xác nhận mua vé";
            mua.UseVisualStyleBackColor = false;
            mua.Click += mua_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Đào, phở và piano", "Mai", "Gặp lại chị bầu", "Tarot" });
            comboBox1.Location = new Point(58, 147);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(255, 28);
            comboBox1.TabIndex = 4;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // Phim
            // 
            Phim.AutoSize = true;
            Phim.Location = new Point(92, 59);
            Phim.Name = "Phim";
            Phim.Size = new Size(0, 20);
            Phim.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.Desktop;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Cyan;
            label2.Location = new Point(58, 109);
            label2.Name = "label2";
            label2.Size = new Size(177, 25);
            label2.TabIndex = 6;
            label2.Text = "Bạn chọn phim nha";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "1", "2", "3" });
            comboBox2.Location = new Point(356, 147);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(142, 28);
            comboBox2.TabIndex = 7;
            // 
            // Phòng
            // 
            Phòng.AutoSize = true;
            Phòng.BackColor = SystemColors.ActiveCaptionText;
            Phòng.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Phòng.ForeColor = Color.Cyan;
            Phòng.Location = new Point(356, 109);
            Phòng.Name = "Phòng";
            Phòng.Size = new Size(67, 25);
            Phòng.TabIndex = 8;
            Phòng.Text = "Phòng";
            Phòng.Click += Phòng_Click;
            // 
            // checkedListBox1
            // 
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Items.AddRange(new object[] { "A1", "A2", "A3", "A4", "A5", "B1", "B2", "B3", "B4", "B5", "C1", "C2", "C3", "C4", "C5" });
            checkedListBox1.Location = new Point(563, 147);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(132, 26);
            checkedListBox1.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ActiveCaptionText;
            label3.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Cyan;
            label3.Location = new Point(563, 109);
            label3.Name = "label3";
            label3.Size = new Size(89, 25);
            label3.TabIndex = 10;
            label3.Text = "Ghế ngồi";
            // 
            // Xoa
            // 
            Xoa.BackColor = Color.LightSalmon;
            Xoa.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Xoa.ForeColor = SystemColors.ButtonFace;
            Xoa.Location = new Point(395, 338);
            Xoa.Name = "Xoa";
            Xoa.Size = new Size(192, 83);
            Xoa.TabIndex = 11;
            Xoa.Text = "Xóa thông tin";
            Xoa.UseVisualStyleBackColor = false;
            // 
            // Bai4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(762, 484);
            Controls.Add(Xoa);
            Controls.Add(label3);
            Controls.Add(checkedListBox1);
            Controls.Add(Phòng);
            Controls.Add(comboBox2);
            Controls.Add(label2);
            Controls.Add(Phim);
            Controls.Add(comboBox1);
            Controls.Add(mua);
            Controls.Add(button1);
            Controls.Add(Nhap);
            Controls.Add(label1);
            DoubleBuffered = true;
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "Bai4";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bai4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox Nhap;
        private Button button1;
        private Button mua;
        private ComboBox comboBox1;
        private Label Phim;
        private Label label2;
        private ComboBox comboBox2;
        private Label Phòng;
        private CheckedListBox checkedListBox1;
        private Label label3;
        private Button Xoa;
    }
}