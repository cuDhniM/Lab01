﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithuchanh1
{
    public partial class Bai5 : Form
    {
        public Bai5()
        {
            InitializeComponent();
        }

        private void soA_TextChanged(object sender, EventArgs e)
        {
            int a;
            if (!int.TryParse(soA.Text, out a))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ");
                soA.Clear();
                soA.Focus();
            }
        }

        private void soB_TextChanged(object sender, EventArgs e)
        {
            int b;
            if (!int.TryParse(soB.Text, out b))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ");
                soB.Clear();
                soB.Focus();
            }
        }

        private void thoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tinh_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(soA.Text) || string.IsNullOrWhiteSpace(soB.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
                return;
            }
            if (!int.TryParse(soA.Text, out int a) || !int.TryParse(soB.Text, out int b))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ");
                return;
            }
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn phép tính");
                return;
            }
            string selectedOperation = comboBox1.SelectedItem!.ToString();
            if (selectedOperation == "Tính bảng cửu chương")
            {
                StringBuilder result = new StringBuilder();
                for (int i = 1; i <= 10; i++)
                {
                    int product = a * i;
                    result.AppendLine($"{a} x {i} = {product}");
                    if (i < 10)
                        result.Append(", ");
                }
                textBox3.Text = result.ToString();
            }
            else if (selectedOperation == "Tính toán giá trị")
            {
                int n = a - b;
                if (n < 0)
                {
                    MessageBox.Show("Giá trị A phải lớn hơn hoặc bằng B để tính giai thừa của (A - B)");
                    return;
                }

                if (b < 1)
                {
                    MessageBox.Show("Giá trị B phải >= 1 để tính tổng S = A¹ + ... + Aᴮ");
                    return;
                }
                BigInteger giaiThua = BigInteger.One;
                for (int i = 1; i <= n; i++)
                    giaiThua *= i;

                double tong = 0;
                for (int i = 1; i <= b; i++)
                    tong += Math.Pow(a, i);
                textBox3.Text = $"(A-B)! = {giaiThua}, S = {tong}";
            }
            else
            {
                MessageBox.Show("Phép tính không hợp lệ");
            }
        }

        private void xoa_Click(object sender, EventArgs e)
        {
            soA.Clear();
            soB.Clear();
            textBox3.Clear();
            comboBox1.SelectedItem = null;
            soA.Focus();
        }
    }
}
