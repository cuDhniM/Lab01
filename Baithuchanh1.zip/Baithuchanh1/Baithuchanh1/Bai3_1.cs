﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithuchanh1
{
    public partial class Bai3_1 : Form
    {
        public Bai3_1()
        {
            InitializeComponent();
        }

        private void menu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Nhap_TextChanged(object sender, EventArgs e)
        {
            if (!long.TryParse(Nhap.Text, out long n))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ");
                return;
            }
        }

        private void doc_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Nhap.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
                return;
            }
            if (!long.TryParse(Nhap.Text, out long n))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ");
                Nhap.Clear();
                KQ.Clear();
                Nhap.Focus();
                return;
            }
            KQ.Text = DocSoLon(n);
            KQ.Text = char.ToUpper(KQ.Text[0]) + KQ.Text.Substring(1);

        }
        private string DocSo(long n)
        {
            switch (n)
            {
                case 0: return "không";
                case 1: return "một";
                case 2: return "hai";
                case 3: return "ba";
                case 4: return "bốn";
                case 5: return "năm";
                case 6: return "sáu";
                case 7: return "bảy";
                case 8: return "tám";
                case 9: return "chín";
            }
            return "";
        }
        private string Doc3ChuSo(long n)
        {
            long tram = n / 100;
            long chuc = (n % 100) / 10;
            long donvi = n % 10;

            string ketQua = "";

            if (tram > 0)
            {
                ketQua += DocSo(tram) + " trăm";
                if (chuc == 0 && donvi > 0) ketQua += " linh";
            }

            if (chuc > 1)
            {
                ketQua += " " + DocSo(chuc) + " mươi";
                if (donvi == 1) ketQua += " mốt";
                else if (donvi == 5) ketQua += " lăm";
                else if (donvi > 0) ketQua += " " + DocSo(donvi);
            }
            else if (chuc == 1)
            {
                ketQua += " mười";
                if (donvi == 1) ketQua += " một";
                else if (donvi == 5) ketQua += " lăm";
                else if (donvi > 0) ketQua += " " + DocSo(donvi);
            }
            else if (chuc == 0 && donvi > 0)
            {
                ketQua += " " + DocSo(donvi);
            }
            return ketQua.Trim();
        }
        private string DocSoLon(long n)
        {
            if (n == 0) return "không";

            string[] donVi = { "", " nghìn", " triệu", " tỷ" };
            string ketQua = "";
            int i = 0;

            while (n > 0)
            {
                int group = (int)(n % 1000);
                if (group > 0)
                {
                    string groupStr = Doc3ChuSo(group) + donVi[i];
                    ketQua = groupStr + " " + ketQua;
                }
                n /= 1000;
                i++;
            }

            return ketQua.Trim();
        }

        private void xoa_Click(object sender, EventArgs e)
        {
            KQ.Clear();
            Nhap.Clear();
            Nhap.Focus();
        }

        private void Bai3_1_Load(object sender, EventArgs e)
        {

        }
    }
}
