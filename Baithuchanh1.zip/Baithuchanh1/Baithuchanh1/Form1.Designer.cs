﻿namespace Baithuchanh1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            bai1 = new Button();
            bai2 = new Button();
            bai3 = new Button();
            bai3_1 = new Button();
            bai4 = new Button();
            bai5 = new Button();
            bai6 = new Button();
            bai7 = new Button();
            bai8 = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // bai1
            // 
            bai1.BackColor = Color.RoyalBlue;
            bai1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai1.ForeColor = Color.RosyBrown;
            bai1.Location = new Point(36, 57);
            bai1.Name = "bai1";
            bai1.Size = new Size(200, 80);
            bai1.TabIndex = 0;
            bai1.Text = "Bài 1";
            bai1.UseVisualStyleBackColor = false;
            bai1.Click += bai1_Click_1;
            // 
            // bai2
            // 
            bai2.BackColor = Color.RoyalBlue;
            bai2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai2.ForeColor = Color.RosyBrown;
            bai2.Location = new Point(170, 154);
            bai2.Name = "bai2";
            bai2.Size = new Size(200, 80);
            bai2.TabIndex = 1;
            bai2.Text = "Bài 2";
            bai2.UseVisualStyleBackColor = false;
            bai2.Click += bai2_Click_1;
            // 
            // bai3
            // 
            bai3.BackColor = Color.MidnightBlue;
            bai3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai3.ForeColor = SystemColors.ActiveCaption;
            bai3.Location = new Point(12, 619);
            bai3.Name = "bai3";
            bai3.Size = new Size(200, 80);
            bai3.TabIndex = 2;
            bai3.Text = "Bài 3";
            bai3.UseVisualStyleBackColor = false;
            bai3.Click += bai3_Click;
            // 
            // bai3_1
            // 
            bai3_1.BackColor = Color.MidnightBlue;
            bai3_1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai3_1.ForeColor = SystemColors.ActiveCaption;
            bai3_1.Location = new Point(170, 768);
            bai3_1.Name = "bai3_1";
            bai3_1.Size = new Size(200, 80);
            bai3_1.TabIndex = 3;
            bai3_1.Text = "Bài 3.1";
            bai3_1.UseVisualStyleBackColor = false;
            bai3_1.Click += bai3_1_Click;
            // 
            // bai4
            // 
            bai4.BackColor = Color.MidnightBlue;
            bai4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai4.ForeColor = SystemColors.ActiveCaption;
            bai4.Location = new Point(497, 808);
            bai4.Name = "bai4";
            bai4.Size = new Size(200, 80);
            bai4.TabIndex = 4;
            bai4.Text = "Bài 4";
            bai4.UseVisualStyleBackColor = false;
            bai4.Click += bai4_Click;
            // 
            // bai5
            // 
            bai5.BackColor = Color.MidnightBlue;
            bai5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai5.ForeColor = SystemColors.ActiveCaption;
            bai5.Location = new Point(817, 768);
            bai5.Name = "bai5";
            bai5.Size = new Size(200, 80);
            bai5.TabIndex = 5;
            bai5.Text = "Bài 5";
            bai5.UseVisualStyleBackColor = false;
            bai5.Click += bai5_Click;
            // 
            // bai6
            // 
            bai6.BackColor = Color.MidnightBlue;
            bai6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai6.ForeColor = SystemColors.ActiveCaption;
            bai6.Location = new Point(968, 619);
            bai6.Name = "bai6";
            bai6.Size = new Size(200, 80);
            bai6.TabIndex = 6;
            bai6.Text = "Bài 6";
            bai6.UseVisualStyleBackColor = false;
            bai6.Click += bai6_Click;
            // 
            // bai7
            // 
            bai7.BackColor = Color.RoyalBlue;
            bai7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai7.ForeColor = Color.RosyBrown;
            bai7.Location = new Point(817, 154);
            bai7.Name = "bai7";
            bai7.Size = new Size(200, 80);
            bai7.TabIndex = 7;
            bai7.Text = "Bài 7";
            bai7.UseVisualStyleBackColor = false;
            bai7.Click += bai7_Click;
            // 
            // bai8
            // 
            bai8.BackColor = Color.RoyalBlue;
            bai8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bai8.ForeColor = Color.RosyBrown;
            bai8.Location = new Point(958, 57);
            bai8.Name = "bai8";
            bai8.Size = new Size(200, 80);
            bai8.TabIndex = 8;
            bai8.Text = "Bài 8";
            bai8.UseVisualStyleBackColor = false;
            bai8.Click += bai8_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(373, 643);
            label1.Name = "label1";
            label1.Size = new Size(457, 44);
            label1.TabIndex = 9;
            label1.Text = "Xin chào các bạn thân iu";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.Info;
            label2.Location = new Point(415, 696);
            label2.Name = "label2";
            label2.Size = new Size(367, 33);
            label2.TabIndex = 10;
            label2.Text = "Trần Minh Đức - 24520331";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 192);
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1180, 916);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(bai8);
            Controls.Add(bai7);
            Controls.Add(bai6);
            Controls.Add(bai5);
            Controls.Add(bai4);
            Controls.Add(bai3_1);
            Controls.Add(bai3);
            Controls.Add(bai2);
            Controls.Add(bai1);
            DoubleBuffered = true;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Menu";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button bai1;
        private Button bai2;
        private Button bai3;
        private Button bai3_1;
        private Button bai4;
        private Button bai5;
        private Button bai6;
        private Button bai7;
        private Button bai8;
        private Label label1;
        private Label label2;
    }
}
