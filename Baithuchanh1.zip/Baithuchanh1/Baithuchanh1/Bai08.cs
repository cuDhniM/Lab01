﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithuchanh1
{
    public partial class Bai08 : Form
    {

        public Bai08()
        {
            InitializeComponent();
        }
        private List<string> monAn = new List<string>
        {
            "Cơm tấm",
            "Phở bò",
            "Bún chả",
            "Hủ tiếu",
            "Bánh mì thịt nướng",
            "Mì Quảng",
            "Lẩu Thái",
            "Cơm chiên Dương Châu"
        };
        private void CapNhatDanhSach()
        {
            monan.Items.Clear(); 

            foreach (string mon in monAn)
                monan.Items.Add(mon);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Bai8_Load(object sender, EventArgs e)
        {
            CapNhatDanhSach();
        }
        private void them_Click(object sender, EventArgs e)
        {
            string monMoi = Nhap.Text.Trim();

            if (string.IsNullOrWhiteSpace(monMoi))
            {
                MessageBox.Show("Vui lòng nhập tên món ăn cần thêm!");
                return;
            }

            if (monAn.Any(m => m.Equals(monMoi, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Món này đã có trong danh sách!");
                Nhap.Clear();
                Nhap.Focus();
                return;
            }

            monAn.Add(monMoi);
            CapNhatDanhSach();

            Nhap.Clear();
            Nhap.Focus();
        }

        private void tim_Click(object sender, EventArgs e)
        {
            if (monAn.Count == 0)
            {
                MessageBox.Show("Danh sách món ăn trống!");
                return;
            }

            Random rnd = new Random();
            int index = rnd.Next(monAn.Count);
            string monChon = monAn[index];

            KQ.Text = monChon;
        }

        private void xoa_Click(object sender, EventArgs e)
        {
            monAn.Clear(); 
            CapNhatDanhSach();
            KQ.Text = "Danh sách món ăn đã được xóa!";
        }
    }
}
