﻿namespace Baithuchanh1
{
    partial class Bai08
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bai08));
            label1 = new Label();
            Nhap = new TextBox();
            them = new Button();
            tim = new Button();
            xoa = new Button();
            button4 = new Button();
            label2 = new Label();
            KQ = new TextBox();
            monan = new ListBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.LightSalmon;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(25, 32);
            label1.Name = "label1";
            label1.Size = new Size(200, 25);
            label1.TabIndex = 0;
            label1.Text = "Nay bồ muốn ăn gì nè";
            // 
            // Nhap
            // 
            Nhap.Location = new Point(231, 33);
            Nhap.Name = "Nhap";
            Nhap.Size = new Size(282, 27);
            Nhap.TabIndex = 1;
            // 
            // them
            // 
            them.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            them.Location = new Point(401, 76);
            them.Name = "them";
            them.Size = new Size(112, 81);
            them.TabIndex = 2;
            them.Text = "Thêm";
            them.UseVisualStyleBackColor = true;
            them.Click += them_Click;
            // 
            // tim
            // 
            tim.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tim.Location = new Point(302, 311);
            tim.Name = "tim";
            tim.Size = new Size(242, 71);
            tim.TabIndex = 3;
            tim.Text = "Tìm món ăn";
            tim.UseVisualStyleBackColor = true;
            tim.Click += tim_Click;
            // 
            // xoa
            // 
            xoa.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            xoa.Location = new Point(665, 311);
            xoa.Name = "xoa";
            xoa.Size = new Size(172, 71);
            xoa.TabIndex = 4;
            xoa.Text = "Xóa";
            xoa.UseVisualStyleBackColor = true;
            xoa.Click += xoa_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.IndianRed;
            button4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = SystemColors.ButtonFace;
            button4.Location = new Point(929, 548);
            button4.Name = "button4";
            button4.Size = new Size(172, 71);
            button4.TabIndex = 5;
            button4.Text = "Back to Menu";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.LightSalmon;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(413, 455);
            label2.Name = "label2";
            label2.Size = new Size(293, 25);
            label2.TabIndex = 6;
            label2.Text = "Món ăn hôm nay fen phải ăng là:";
            // 
            // KQ
            // 
            KQ.Location = new Point(247, 483);
            KQ.Name = "KQ";
            KQ.Size = new Size(609, 27);
            KQ.TabIndex = 7;
            // 
            // monan
            // 
            monan.FormattingEnabled = true;
            monan.Items.AddRange(new object[] { "Cơm tấm", "Phở bò", "Bún chả", "Hủ tiếu", "Mì xào hải sản", "Bánh mì thịt nướng", "Lẩu thái", "Cơm chiên dương châu" });
            monan.Location = new Point(540, 32);
            monan.Name = "monan";
            monan.Size = new Size(505, 244);
            monan.TabIndex = 8;
            // 
            // Bai08
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1113, 631);
            Controls.Add(monan);
            Controls.Add(KQ);
            Controls.Add(label2);
            Controls.Add(button4);
            Controls.Add(xoa);
            Controls.Add(tim);
            Controls.Add(them);
            Controls.Add(Nhap);
            Controls.Add(label1);
            DoubleBuffered = true;
            Name = "Bai08";
            Text = "Bai08";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox Nhap;
        private Button them;
        private Button tim;
        private Button xoa;
        private Button button4;
        private Label label2;
        private TextBox KQ;
        private ListBox monan;
    }
}