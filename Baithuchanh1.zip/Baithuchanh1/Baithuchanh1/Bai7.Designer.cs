﻿namespace Baithuchanh1
{
    partial class Bai7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            hoten = new TextBox();
            nhap = new Button();
            xuat = new Button();
            tinh = new Button();
            xoa = new Button();
            menu = new Button();
            label2 = new Label();
            kq = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(25, 35);
            label1.Name = "label1";
            label1.Size = new Size(127, 20);
            label1.TabIndex = 0;
            label1.Text = "Nhập tên và điểm";
            // 
            // hoten
            // 
            hoten.Location = new Point(158, 28);
            hoten.Name = "hoten";
            hoten.Size = new Size(718, 27);
            hoten.TabIndex = 1;
            // 
            // nhap
            // 
            nhap.BackColor = SystemColors.ButtonShadow;
            nhap.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nhap.ForeColor = SystemColors.ButtonFace;
            nhap.Location = new Point(240, 148);
            nhap.Name = "nhap";
            nhap.Size = new Size(152, 56);
            nhap.TabIndex = 2;
            nhap.Text = "Nhập thông tin";
            nhap.UseVisualStyleBackColor = false;
            nhap.Click += nhap_Click;
            // 
            // xuat
            // 
            xuat.BackColor = SystemColors.ButtonShadow;
            xuat.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            xuat.ForeColor = SystemColors.ButtonFace;
            xuat.Location = new Point(714, 148);
            xuat.Name = "xuat";
            xuat.Size = new Size(152, 56);
            xuat.TabIndex = 3;
            xuat.Text = "Xuất";
            xuat.UseVisualStyleBackColor = false;
            xuat.Click += xuat_Click;
            // 
            // tinh
            // 
            tinh.BackColor = SystemColors.ControlDark;
            tinh.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tinh.ForeColor = SystemColors.ButtonFace;
            tinh.Location = new Point(1220, 148);
            tinh.Name = "tinh";
            tinh.Size = new Size(152, 56);
            tinh.TabIndex = 4;
            tinh.Text = "Tính";
            tinh.UseVisualStyleBackColor = false;
            tinh.Click += tinh_Click;
            // 
            // xoa
            // 
            xoa.BackColor = SystemColors.ControlDark;
            xoa.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            xoa.ForeColor = SystemColors.ButtonFace;
            xoa.Location = new Point(1496, 17);
            xoa.Name = "xoa";
            xoa.Size = new Size(152, 56);
            xoa.TabIndex = 5;
            xoa.Text = "Xóa";
            xoa.UseVisualStyleBackColor = false;
            xoa.Click += xoa_Click;
            // 
            // menu
            // 
            menu.Location = new Point(1525, 624);
            menu.Name = "menu";
            menu.Size = new Size(123, 38);
            menu.TabIndex = 6;
            menu.Text = "Back to Menu";
            menu.UseVisualStyleBackColor = true;
            menu.Click += menu_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 200);
            label2.Name = "label2";
            label2.Size = new Size(60, 20);
            label2.TabIndex = 7;
            label2.Text = "Kết quả";
            label2.Click += label2_Click;
            // 
            // kq
            // 
            kq.Location = new Point(12, 223);
            kq.Multiline = true;
            kq.Name = "kq";
            kq.ReadOnly = true;
            kq.ScrollBars = ScrollBars.Vertical;
            kq.Size = new Size(1613, 395);
            kq.TabIndex = 8;
            // 
            // Bai7
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1660, 688);
            Controls.Add(kq);
            Controls.Add(label2);
            Controls.Add(menu);
            Controls.Add(xoa);
            Controls.Add(tinh);
            Controls.Add(xuat);
            Controls.Add(nhap);
            Controls.Add(hoten);
            Controls.Add(label1);
            Name = "Bai7";
            Text = "Bai7";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox hoten;
        private Button nhap;
        private Button xuat;
        private Button tinh;
        private Button xoa;
        private Button menu;
        private Label label2;
        private TextBox kq;
    }
}