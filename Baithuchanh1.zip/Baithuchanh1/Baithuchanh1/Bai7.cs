﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithuchanh1
{
    public partial class Bai7 : Form
    {
        string hoTen = "";
        List<double> diem = new List<double>();
        public Bai7()
        {
            InitializeComponent();
        }

        private void menu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void xoa_Click(object sender, EventArgs e)
        {
            hoten.Clear();
            kq.Clear();
            hoten.Focus();
            diem.Clear();
            hoTen = "";
        }

        private void nhap_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(hoten.Text))
            {
                MessageBox.Show("Vui lòng nhập họ tên và danh sách điểm!");
                return;
            }

            try
            {
                string[] parts = hoten.Text.Split(new char[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length < 2)
                {
                    MessageBox.Show("Sai định dạng! Phải có ít nhất họ tên và 1 điểm.");
                    return;
                }

                hoTen = parts[0].Trim();

                diem = parts
                    .Skip(1)
                    .Select(p => double.Parse(p.Replace(',', '.'), CultureInfo.InvariantCulture))
                    .ToList();

                MessageBox.Show("Đã nhập đúng định dạng!");
            }
            catch
            {
                MessageBox.Show("Sai định dạng điểm! Vui lòng nhập lại (vd: Nguyễn Thị A, 7.5, 5, 8, 10)");
            }
        }

        private void xuat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(hoTen) || diem.Count == 0)
            {
                MessageBox.Show("Chưa có dữ liệu để xuất!");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Họ và tên: {hoTen}");
            sb.Append("Danh sách điểm: ");
            for (int i = 0; i < diem.Count; i++)
                sb.Append($"Môn {i + 1}: {diem[i]}  ");

            kq.Text = sb.ToString();
        }

        private void tinh_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(hoTen) || diem.Count == 0)
            {
                MessageBox.Show("Chưa có dữ liệu để tính toán!");
                return;
            }

            double dtb = diem.Average();
            double max = diem.Max();
            double min = diem.Min();
            int dau = diem.Count(d => d >= 5);
            int rot = diem.Count(d => d < 5);

            string xeploai = XepLoai(dtb, diem);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Họ và tên: {hoTen}");
            sb.AppendLine("Danh sách điểm:");
            for (int i = 0; i < diem.Count; i++)
                sb.AppendLine($"  Môn {i + 1}: {diem[i]}");

            sb.AppendLine($"Điểm trung bình: {dtb:F2}");
            sb.AppendLine($"Điểm cao nhất: {max}");
            sb.AppendLine($"Điểm thấp nhất: {min}");
            sb.AppendLine($"Số môn đậu: {dau}");
            sb.AppendLine($"Số môn không đậu: {rot}");
            sb.AppendLine($"Xếp loại: {xeploai}");

            kq.Text = sb.ToString();
        }
        private string XepLoai(double dtb, List<double> ds)
        {
            if (dtb >= 8 && ds.All(d => d >= 6.5))
                return "Giỏi";
            else if (dtb >= 6.5 && ds.All(d => d >= 5))
                return "Khá";
            else if (dtb >= 5 && ds.All(d => d >= 3.5))
                return "Trung bình";
            else if (dtb >= 3.5 && ds.All(d => d >= 2))
                return "Yếu";
            else
                return "Kém";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
