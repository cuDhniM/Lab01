﻿namespace Baithuchanh1
{
    partial class Bai1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BackMenu = new Button();
            ST1 = new Label();
            ST2 = new Label();
            KQ = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            Tinh = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // BackMenu
            // 
            BackMenu.Location = new Point(801, 25);
            BackMenu.Name = "BackMenu";
            BackMenu.Size = new Size(159, 40);
            BackMenu.TabIndex = 0;
            BackMenu.Text = "Back to Menu";
            BackMenu.UseVisualStyleBackColor = true;
            BackMenu.Click += BackMenu_Click;
            // 
            // ST1
            // 
            ST1.AutoSize = true;
            ST1.BackColor = Color.Silver;
            ST1.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ST1.Location = new Point(88, 129);
            ST1.Name = "ST1";
            ST1.Size = new Size(144, 27);
            ST1.TabIndex = 1;
            ST1.Text = "Số thứ nhất";
            ST1.Click += label1_Click;
            // 
            // ST2
            // 
            ST2.AutoSize = true;
            ST2.BackColor = Color.Silver;
            ST2.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ST2.Location = new Point(88, 223);
            ST2.Name = "ST2";
            ST2.Size = new Size(128, 27);
            ST2.TabIndex = 2;
            ST2.Text = "Số thứ hai";
            // 
            // KQ
            // 
            KQ.AutoSize = true;
            KQ.BackColor = Color.Silver;
            KQ.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            KQ.Location = new Point(88, 319);
            KQ.Name = "KQ";
            KQ.Size = new Size(98, 27);
            KQ.TabIndex = 3;
            KQ.Text = "Kết quả";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(368, 129);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(442, 27);
            textBox1.TabIndex = 4;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(368, 223);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(442, 27);
            textBox2.TabIndex = 5;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(368, 319);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(442, 27);
            textBox3.TabIndex = 6;
            // 
            // Tinh
            // 
            Tinh.Font = new Font("Arial Rounded MT Bold", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Tinh.Location = new Point(335, 373);
            Tinh.Name = "Tinh";
            Tinh.Size = new Size(206, 57);
            Tinh.TabIndex = 7;
            Tinh.Text = "Tính";
            Tinh.UseVisualStyleBackColor = true;
            Tinh.Click += Tinh_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Cornsilk;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(255, 128, 255);
            label1.Location = new Point(335, 47);
            label1.Name = "label1";
            label1.Size = new Size(268, 35);
            label1.TabIndex = 8;
            label1.Text = "Tổng 2 số nguyên";
            // 
            // Bai1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 192, 255);
            ClientSize = new Size(978, 458);
            Controls.Add(label1);
            Controls.Add(Tinh);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(KQ);
            Controls.Add(ST2);
            Controls.Add(ST1);
            Controls.Add(BackMenu);
            Name = "Bai1";
            Text = "Bai1";
            Load += Bai1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BackMenu;
        private Label ST1;
        private Label ST2;
        private Label KQ;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button Tinh;
        private Label label1;
    }
}