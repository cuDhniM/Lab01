﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithuchanh1
{
    public partial class Bai1 : Form
    {
        public Bai1()
        {
            InitializeComponent();
        }
        private void bai1_Click_1(object sender, EventArgs e)
        {

        }

        private void Bai1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int st1;
            if (!int.TryParse(textBox1.Text, out st1))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ");
                return;
            }
        }



        private void Tinh_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
                return;
            }
            int st1, st2;
            if (!int.TryParse(textBox1.Text, out st1) || !int.TryParse(textBox2.Text, out st2))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ");
                return;
            }
            long kq = (long)st1 + st2;
            textBox3.Text = kq.ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int st2;
            if (!int.TryParse(textBox1.Text, out st2))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ");
                return;
            }
        }
         private void BackMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    } 
}
