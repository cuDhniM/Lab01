﻿namespace Baithuchanh1
{
    partial class Bai6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ngaysinh = new DateTimePicker();
            label1 = new Label();
            xacdinh = new Button();
            xoa = new Button();
            menu = new Button();
            kq = new TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // ngaysinh
            // 
            ngaysinh.Location = new Point(249, 36);
            ngaysinh.Name = "ngaysinh";
            ngaysinh.Size = new Size(313, 27);
            ngaysinh.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(47, 37);
            label1.Name = "label1";
            label1.Size = new Size(196, 25);
            label1.TabIndex = 1;
            label1.Text = "Ngày bạn được ra đời";
            // 
            // xacdinh
            // 
            xacdinh.Location = new Point(47, 137);
            xacdinh.Name = "xacdinh";
            xacdinh.Size = new Size(151, 50);
            xacdinh.TabIndex = 2;
            xacdinh.Text = "Xác định cung hoàng đạo";
            xacdinh.UseVisualStyleBackColor = true;
            xacdinh.Click += xacdinh_Click;
            // 
            // xoa
            // 
            xoa.Location = new Point(343, 137);
            xoa.Name = "xoa";
            xoa.Size = new Size(151, 50);
            xoa.TabIndex = 3;
            xoa.Text = "Xóa";
            xoa.UseVisualStyleBackColor = true;
            xoa.Click += xoa_Click;
            // 
            // menu
            // 
            menu.Location = new Point(635, 137);
            menu.Name = "menu";
            menu.Size = new Size(151, 50);
            menu.TabIndex = 4;
            menu.Text = "Back to Menu";
            menu.UseVisualStyleBackColor = true;
            menu.Click += menu_Click;
            // 
            // kq
            // 
            kq.Location = new Point(312, 277);
            kq.Name = "kq";
            kq.Size = new Size(414, 27);
            kq.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(47, 277);
            label2.Name = "label2";
            label2.Size = new Size(224, 25);
            label2.TabIndex = 6;
            label2.Text = "Cung hoàng đạo của bạn";
            // 
            // Bai6
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(839, 370);
            Controls.Add(label2);
            Controls.Add(kq);
            Controls.Add(menu);
            Controls.Add(xoa);
            Controls.Add(xacdinh);
            Controls.Add(label1);
            Controls.Add(ngaysinh);
            Name = "Bai6";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bai6";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker ngaysinh;
        private Label label1;
        private Button xacdinh;
        private Button xoa;
        private Button menu;
        private TextBox kq;
        private Label label2;
    }
}