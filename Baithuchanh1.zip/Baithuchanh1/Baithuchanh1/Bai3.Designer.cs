﻿namespace Baithuchanh1
{
    partial class Bai3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Nhap = new TextBox();
            label2 = new Label();
            KQ = new TextBox();
            Doc = new Button();
            Xoa = new Button();
            Menu = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(97, 106);
            label1.Name = "label1";
            label1.Size = new Size(356, 27);
            label1.TabIndex = 0;
            label1.Text = "Nhập vào số nguyên từ 0 đến 9";
            // 
            // Nhap
            // 
            Nhap.Location = new Point(483, 106);
            Nhap.Name = "Nhap";
            Nhap.Size = new Size(196, 27);
            Nhap.TabIndex = 1;
            Nhap.TextChanged += Nhap_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(97, 265);
            label2.Name = "label2";
            label2.Size = new Size(98, 27);
            label2.TabIndex = 2;
            label2.Text = "Kết quả";
            // 
            // KQ
            // 
            KQ.Location = new Point(97, 314);
            KQ.Name = "KQ";
            KQ.Size = new Size(196, 27);
            KQ.TabIndex = 3;
            // 
            // Doc
            // 
            Doc.Location = new Point(749, 134);
            Doc.Name = "Doc";
            Doc.Size = new Size(160, 68);
            Doc.TabIndex = 4;
            Doc.Text = "Đọc";
            Doc.UseVisualStyleBackColor = true;
            Doc.Click += Doc_Click;
            // 
            // Xoa
            // 
            Xoa.Location = new Point(749, 265);
            Xoa.Name = "Xoa";
            Xoa.Size = new Size(160, 68);
            Xoa.TabIndex = 5;
            Xoa.Text = "Xóa";
            Xoa.UseVisualStyleBackColor = true;
            Xoa.Click += Xoa_Click;
            // 
            // Menu
            // 
            Menu.Location = new Point(749, 401);
            Menu.Name = "Menu";
            Menu.Size = new Size(160, 68);
            Menu.TabIndex = 6;
            Menu.Text = "Back to Menu";
            Menu.UseVisualStyleBackColor = true;
            Menu.Click += Menu_Click;
            // 
            // Bai3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(950, 591);
            Controls.Add(Menu);
            Controls.Add(Xoa);
            Controls.Add(Doc);
            Controls.Add(KQ);
            Controls.Add(label2);
            Controls.Add(Nhap);
            Controls.Add(label1);
            Name = "Bai3";
            Text = "Bai3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox Nhap;
        private Label label2;
        private TextBox KQ;
        private Button Doc;
        private Button Xoa;
        private Button Menu;
    }
}