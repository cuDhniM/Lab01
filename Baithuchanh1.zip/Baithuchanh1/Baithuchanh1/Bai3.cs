﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithuchanh1
{
    public partial class Bai3 : Form
    {
        public Bai3()
        {
            InitializeComponent();
        }

        private void Menu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Doc_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Nhap.Text))
            {
                MessageBox.Show("Vui lòng nhập số nguyên từ 0 đến 9");
                Nhap.Focus();
                return;
            }
            int n;
            if (!int.TryParse(Nhap.Text, out n) || n < 0 || n > 9)
            {
                MessageBox.Show("Vui lòng nhập số nguyên từ 0 đến 9");
                Nhap.Clear();
                KQ.Clear();
                Nhap.Focus();
                return;
            }
            string ketQua = "";
            switch (n)
            {
                case 0: ketQua = "Không"; break;
                case 1: ketQua = "Một"; break;
                case 2: ketQua = "Hai"; break;
                case 3: ketQua = "Ba"; break;
                case 4: ketQua = "Bốn"; break;
                case 5: ketQua = "Năm"; break;
                case 6: ketQua = "Sáu"; break;
                case 7: ketQua = "Bảy"; break;
                case 8: ketQua = "Tám"; break;
                case 9: ketQua = "Chín"; break;
            }
            KQ.Text = ketQua;
        }

        private void Nhap_TextChanged(object sender, EventArgs e)
        {
            int n;
            if (!int.TryParse(Nhap.Text, out n) || n < 0 || n > 9)
            {
                MessageBox.Show("Vui lòng nhập số nguyên từ 0 đến 9");
                Nhap.Clear();
                KQ.Clear();
                Nhap.Focus();
            }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            Nhap.Clear();
            KQ.Clear();
            Nhap.Focus();
        }
    }
}
