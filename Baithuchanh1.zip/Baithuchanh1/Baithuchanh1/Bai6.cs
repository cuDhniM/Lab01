﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithuchanh1
{
    public partial class Bai6 : Form
    {
        public Bai6()
        {
            InitializeComponent();
        }

        private void menu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void xoa_Click(object sender, EventArgs e)
        {
            ngaysinh.Value = DateTime.Today;
            kq.Clear();
        }

        private void xacdinh_Click(object sender, EventArgs e)
        {
            DateTime ngaysinh1 = ngaysinh.Value;
            int ngay = ngaysinh1.Day;
            int thang = ngaysinh1.Month;
            string cung = XacDinhCung(ngay, thang);
            kq.Text = cung;
        }
        private string XacDinhCung(int ngay, int thang)
        {
            return (thang, ngay) switch
            {
                (1, >= 20) or (2, <= 18) => "Bảo Bình (Aquarius)",
                (2, >= 19) or (3, <= 20) => "Song Ngư (Pisces)",
                (3, >= 21) or (4, <= 19) => "Bạch Dương (Aries)",
                (4, >= 20) or (5, <= 20) => "Kim Ngưu (Taurus)",
                (5, >= 21) or (6, <= 21) => "Song Tử (Gemini)",
                (6, >= 22) or (7, <= 22) => "Cự Giải (Cancer)",
                (7, >= 23) or (8, <= 22) => "Sư Tử (Leo)",
                (8, >= 23) or (9, <= 22) => "Xử Nữ (Virgo)",
                (9, >= 23) or (10, <= 23) => "Thiên Bình (Libra)",
                (10, >= 24) or (11, <= 22) => "Bọ Cạp (Scorpio)",
                (11, >= 23) or (12, <= 21) => "Nhân Mã (Sagittarius)",
                (12, >= 22) or (1, <= 19) => "Ma Kết (Capricorn)",
                _ => "Không xác định"
            };
        }
    }
}
