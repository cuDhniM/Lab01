﻿namespace Baithuchanh1
{
    partial class Bai5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            soA = new TextBox();
            soB = new TextBox();
            tinh = new Button();
            xoa = new Button();
            thoat = new Button();
            textBox3 = new TextBox();
            label3 = new Label();
            comboBox1 = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(37, 41);
            label1.Name = "label1";
            label1.Size = new Size(76, 25);
            label1.TabIndex = 0;
            label1.Text = "Nhập A";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(454, 44);
            label2.Name = "label2";
            label2.Size = new Size(75, 25);
            label2.TabIndex = 1;
            label2.Text = "Nhập B";
            // 
            // soA
            // 
            soA.Location = new Point(119, 42);
            soA.Name = "soA";
            soA.Size = new Size(262, 27);
            soA.TabIndex = 2;
            soA.TextChanged += soA_TextChanged;
            // 
            // soB
            // 
            soB.Location = new Point(554, 45);
            soB.Name = "soB";
            soB.Size = new Size(262, 27);
            soB.TabIndex = 3;
            soB.TextChanged += soB_TextChanged;
            // 
            // tinh
            // 
            tinh.Location = new Point(63, 208);
            tinh.Name = "tinh";
            tinh.Size = new Size(158, 60);
            tinh.TabIndex = 4;
            tinh.Text = "Tính các giá trị";
            tinh.UseVisualStyleBackColor = true;
            tinh.Click += tinh_Click;
            // 
            // xoa
            // 
            xoa.Location = new Point(354, 208);
            xoa.Name = "xoa";
            xoa.Size = new Size(158, 60);
            xoa.TabIndex = 5;
            xoa.Text = "Xóa";
            xoa.UseVisualStyleBackColor = true;
            xoa.Click += xoa_Click;
            // 
            // thoat
            // 
            thoat.Location = new Point(658, 208);
            thoat.Name = "thoat";
            thoat.Size = new Size(158, 60);
            thoat.TabIndex = 6;
            thoat.Text = "Back to Menu";
            thoat.UseVisualStyleBackColor = true;
            thoat.Click += thoat_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(117, 316);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(743, 27);
            textBox3.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(37, 315);
            label3.Name = "label3";
            label3.Size = new Size(78, 25);
            label3.TabIndex = 8;
            label3.Text = "Kết quả";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Tính bảng cửu chương", "Tính toán giá trị" });
            comboBox1.Location = new Point(311, 115);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(253, 28);
            comboBox1.TabIndex = 9;
            // 
            // Bai5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(872, 405);
            Controls.Add(comboBox1);
            Controls.Add(label3);
            Controls.Add(textBox3);
            Controls.Add(thoat);
            Controls.Add(xoa);
            Controls.Add(tinh);
            Controls.Add(soB);
            Controls.Add(soA);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Bai5";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bai5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox soA;
        private TextBox soB;
        private Button tinh;
        private Button xoa;
        private Button thoat;
        private TextBox textBox3;
        private Label label3;
        private ComboBox comboBox1;
    }
}