﻿namespace Baithuchanh1
{
    partial class Bai2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Tim = new Button();
            Xoa = new Button();
            Thoat = new Button();
            sothu1 = new Label();
            textBox1 = new TextBox();
            sothu2 = new Label();
            textBox2 = new TextBox();
            sothu3 = new Label();
            textBox3 = new TextBox();
            Max = new TextBox();
            Min = new TextBox();
            sln = new Label();
            snn = new Label();
            SuspendLayout();
            // 
            // Tim
            // 
            Tim.Location = new Point(283, 176);
            Tim.Name = "Tim";
            Tim.Size = new Size(144, 56);
            Tim.TabIndex = 0;
            Tim.Text = "Tìm";
            Tim.UseVisualStyleBackColor = true;
            Tim.Click += Tim_Click;
            // 
            // Xoa
            // 
            Xoa.Location = new Point(532, 176);
            Xoa.Name = "Xoa";
            Xoa.Size = new Size(144, 56);
            Xoa.TabIndex = 1;
            Xoa.Text = "Xóa";
            Xoa.UseVisualStyleBackColor = true;
            Xoa.Click += Xoa_Click;
            // 
            // Thoat
            // 
            Thoat.Location = new Point(900, 437);
            Thoat.Name = "Thoat";
            Thoat.Size = new Size(106, 58);
            Thoat.TabIndex = 2;
            Thoat.Text = "Back to Menu";
            Thoat.UseVisualStyleBackColor = true;
            Thoat.Click += Thoat_Click;
            // 
            // sothu1
            // 
            sothu1.AutoSize = true;
            sothu1.Location = new Point(34, 63);
            sothu1.Name = "sothu1";
            sothu1.Size = new Size(85, 20);
            sothu1.TabIndex = 3;
            sothu1.Text = "Số thứ nhất";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(125, 60);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(175, 27);
            textBox1.TabIndex = 4;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // sothu2
            // 
            sothu2.AutoSize = true;
            sothu2.Location = new Point(329, 63);
            sothu2.Name = "sothu2";
            sothu2.Size = new Size(76, 20);
            sothu2.TabIndex = 5;
            sothu2.Text = "Số thứ hai";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(425, 60);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(175, 27);
            textBox2.TabIndex = 6;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // sothu3
            // 
            sothu3.AutoSize = true;
            sothu3.Location = new Point(642, 63);
            sothu3.Name = "sothu3";
            sothu3.Size = new Size(73, 20);
            sothu3.TabIndex = 7;
            sothu3.Text = "Số thứ ba";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(730, 60);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(175, 27);
            textBox3.TabIndex = 8;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // Max
            // 
            Max.Location = new Point(230, 313);
            Max.Name = "Max";
            Max.Size = new Size(175, 27);
            Max.TabIndex = 9;
            // 
            // Min
            // 
            Min.Location = new Point(701, 313);
            Min.Name = "Min";
            Min.Size = new Size(175, 27);
            Min.TabIndex = 10;
            // 
            // sln
            // 
            sln.AutoSize = true;
            sln.Location = new Point(125, 316);
            sln.Name = "sln";
            sln.Size = new Size(84, 20);
            sln.TabIndex = 11;
            sln.Text = "Số lớn nhất";
            // 
            // snn
            // 
            snn.AutoSize = true;
            snn.Location = new Point(588, 316);
            snn.Name = "snn";
            snn.Size = new Size(88, 20);
            snn.TabIndex = 12;
            snn.Text = "Số nhỏ nhất";
            // 
            // Bai2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1018, 507);
            Controls.Add(snn);
            Controls.Add(sln);
            Controls.Add(Min);
            Controls.Add(Max);
            Controls.Add(textBox3);
            Controls.Add(sothu3);
            Controls.Add(textBox2);
            Controls.Add(sothu2);
            Controls.Add(textBox1);
            Controls.Add(sothu1);
            Controls.Add(Thoat);
            Controls.Add(Xoa);
            Controls.Add(Tim);
            Name = "Bai2";
            Text = "Bai2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Tim;
        private Button Xoa;
        private Button Thoat;
        private Label sothu1;
        private TextBox textBox1;
        private Label sothu2;
        private TextBox textBox2;
        private Label sothu3;
        private TextBox textBox3;
        private TextBox Max;
        private TextBox Min;
        private Label sln;
        private Label snn;
    }
}