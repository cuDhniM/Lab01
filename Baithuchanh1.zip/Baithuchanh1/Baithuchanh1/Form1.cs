using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Baithuchanh1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void bai1_Click_1(object sender, EventArgs e)
        {
            Baithuchanh1.Bai1 f = new Baithuchanh1.Bai1();
            f.ShowDialog();
        }

        private void bai2_Click_1(object sender, EventArgs e)
        {
            Baithuchanh1.Bai2 f = new Baithuchanh1.Bai2();
            f.ShowDialog();
        }

        private void bai3_Click(object sender, EventArgs e)
        {
            Baithuchanh1.Bai3 f = new Baithuchanh1.Bai3();
            f.ShowDialog();
        }

        private void bai3_1_Click(object sender, EventArgs e)
        {
            Baithuchanh1.Bai3_1 f = new Baithuchanh1.Bai3_1();
            f.ShowDialog();
        }

        private void bai4_Click(object sender, EventArgs e)
        {
            Baithuchanh1.Bai4 f = new Baithuchanh1.Bai4();
            f.ShowDialog();
        }

        private void bai5_Click(object sender, EventArgs e)
        {
            Baithuchanh1.Bai5 f = new Baithuchanh1.Bai5();
            f.ShowDialog();
        }

        private void bai6_Click(object sender, EventArgs e)
        {
            Baithuchanh1.Bai6 f = new Baithuchanh1.Bai6();
            f.ShowDialog();
        }

        private void bai7_Click(object sender, EventArgs e)
        {
            Baithuchanh1.Bai7 f = new Baithuchanh1.Bai7();
            f.ShowDialog();
        }

        private void bai8_Click(object sender, EventArgs e)
        {
            Baithuchanh1.Bai08 f = new Baithuchanh1.Bai08();
            f.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
