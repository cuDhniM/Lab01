﻿namespace Baithuchanh1
{
    partial class Bai3_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            Nhap = new TextBox();
            KQ = new TextBox();
            doc = new Button();
            xoa = new Button();
            menu = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(55, 96);
            label1.Name = "label1";
            label1.Size = new Size(270, 27);
            label1.TabIndex = 0;
            label1.Text = "Năn nỉ nhập số nguyên";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(55, 275);
            label2.Name = "label2";
            label2.Size = new Size(98, 27);
            label2.TabIndex = 1;
            label2.Text = "Kết quả";
            // 
            // Nhap
            // 
            Nhap.Location = new Point(331, 96);
            Nhap.Name = "Nhap";
            Nhap.Size = new Size(418, 27);
            Nhap.TabIndex = 2;
            Nhap.TextChanged += Nhap_TextChanged;
            // 
            // KQ
            // 
            KQ.Location = new Point(55, 331);
            KQ.Name = "KQ";
            KQ.Size = new Size(694, 27);
            KQ.TabIndex = 3;
            // 
            // doc
            // 
            doc.Location = new Point(811, 84);
            doc.Name = "doc";
            doc.Size = new Size(126, 76);
            doc.TabIndex = 4;
            doc.Text = "Đọc";
            doc.UseVisualStyleBackColor = true;
            doc.Click += doc_Click;
            // 
            // xoa
            // 
            xoa.Location = new Point(811, 253);
            xoa.Name = "xoa";
            xoa.Size = new Size(126, 76);
            xoa.TabIndex = 5;
            xoa.Text = "Xóa";
            xoa.UseVisualStyleBackColor = true;
            xoa.Click += xoa_Click;
            // 
            // menu
            // 
            menu.Location = new Point(839, 560);
            menu.Name = "menu";
            menu.Size = new Size(126, 76);
            menu.TabIndex = 6;
            menu.Text = "Back to Menu";
            menu.UseVisualStyleBackColor = true;
            menu.Click += menu_Click;
            // 
            // Bai3_1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(977, 648);
            Controls.Add(menu);
            Controls.Add(xoa);
            Controls.Add(doc);
            Controls.Add(KQ);
            Controls.Add(Nhap);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Bai3_1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bai3_1";
            Load += Bai3_1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox Nhap;
        private TextBox KQ;
        private Button doc;
        private Button xoa;
        private Button menu;
    }
}