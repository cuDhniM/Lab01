﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithuchanh1
{
    public partial class Bai4 : Form
    {
        Dictionary<string, int> GiaPhim = new Dictionary<string, int>()
        {
            { "Đào, phở và piano", 45000 },
            { "Mai", 100000 },
            { "Gặp lại chị bầu", 70000 },
            { "Tarot", 90000 }
        };

        Dictionary<string, List<int>> phongPhim = new Dictionary<string, List<int>>()
    {
        { "Đào, phở và piano", new List<int>{1,2,3} },
        { "Mai", new List<int>{2,3} },
        { "Gặp lại chị bầu", new List<int>{1} },
        { "Tarot", new List<int>{3} }
    };
        HashSet<string> gheDaChon = new HashSet<string>();
        public Bai4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Phòng_Click(object sender, EventArgs e)
        {

        }

        private void mua_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Nhap_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
